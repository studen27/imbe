/** Automatically generated file. DO NOT MODIFY */
package kr.ac.mju.strangelibrary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}