/** Automatically generated file. DO NOT MODIFY */
package com.example.imbedproject.v021;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}